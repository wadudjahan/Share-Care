package com.example.nav_bar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Fragment_one extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_one);
    }
}